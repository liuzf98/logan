//
//  InitialConditions.cpp
//  Euler1D
//
//  Created by Andrew Ross on 2017-04-03.
//  Copyright © 2017 Andrew Ross. All rights reserved.
//

#include "InitialConditions.hpp"
